// redir.js
var i1;
var i2;

function ytCheck() {
  i1 = setInterval(function() {
  if (sessionStorage.getItem("noytabredirect") == "1") {
    if (location.href.includes("watch?v=")) {
      sessionStorage.setItem("cloc",location.href)
    }
    if (location.href != sessionStorage.getItem("cloc")) {
      sessionStorage.setItem("noytabredirect","0")
    }
  }
  console.log("YTABCheckerServiceLog")
  if (location.href.includes("watch?v=")) {
    if (location.href.includes("&noytabredirect=1")) {
      sessionStorage.setItem("noytabredirect","1")
    } else if (sessionStorage.getItem("noytabredirect") == "1") {
      console.log("noytabredirect")
      clearInterval(i1)
    } else {
      var filter1 = location.href.replace("www.youtube.com/watch","ytsimplified.pages.dev/")
      location.replace(filter1.replace("youtube.com/watch","ytsimplified.pages.dev/"))
    }
  }
},1000)
i2 = setInterval(function() {
  if (location.href.includes("&noytabredirect=1")) {
      sessionStorage.setItem("noytabredirect","1")
      clearInterval(i2)
  }
},50)
}

if (location.href.includes("youtube.com")) {
  ytCheck()
} else {
  sessionStorage.setItem("extInstalled","3.2")
}