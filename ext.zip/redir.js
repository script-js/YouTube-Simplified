// redir.js
if (location.href.includes("youtube.com")) {
setInterval(function() {
  if (sessionStorage.getItem("noytabredirect") == "1") {
    if (location.href.includes("watch?v=")) {
      sessionStorage.setItem("cloc",location.href)
    }
    if (location.href != sessionStorage.getItem("cloc")) {
      sessionStorage.setItem("noytabredirect","0")
    }
  }
  console.log("YTABCheckerServiceLog")
  if (location.href.includes("watch?v=")) {
    if (location.href.includes("&noytabredirect=1")) {
      sessionStorage.setItem("noytabredirect","1")
    } else if (sessionStorage.getItem("noytabredirect") == "1") {
      console.log("noytabredirect")
    } else {
      var filter1 = location.href.replace("www.youtube.com/watch","ytadblock.script-js.repl.co/")
      location.replace(filter1.replace("youtube.com/watch","ytadblock.script-js.repl.co/"))
    }
  }
},1000)

setInterval(function() {
  if (location.href.includes("&noytabredirect=1")) {
      sessionStorage.setItem("noytabredirect","1")
  }
},300)
} else {
  sessionStorage.setItem("extInstalled","2.1")
}